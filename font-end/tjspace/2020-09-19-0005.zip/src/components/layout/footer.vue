<template>
  <q-footer reveal bordered class="bg-grey-8 text-white page-footer">
    <q-toolbar>
      <span class="footer-name">TJSPACE·同济大学社群</span>
      <span class="footer-id">津ICP备20006438号</span>
    </q-toolbar>
  </q-footer>
</template>

<script>
export default {};
</script>

<style>
</style>